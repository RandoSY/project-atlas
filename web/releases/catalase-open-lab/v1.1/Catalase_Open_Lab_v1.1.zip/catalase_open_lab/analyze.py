"""Catalase Open Lab v1.1. Standard-library Python; one slope per independent run.
Usage: python analyze.py measurements.csv --start 10 --end 40
Use the time window fixed during the pilot. Blank data stay missing. No imputation.
"""
import argparse, csv, statistics as st, math, json
from collections import defaultdict
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('csv');p.add_argument('--start',type=int,default=10);p.add_argument('--end',type=int,default=40);a=p.parse_args()
if a.start<0 or a.start>=a.end or a.start%5 or a.end%5 or a.end>60: p.error('Use a pilot-fixed window of 5-second increments within 0–60 s.')
expected=set(range(a.start,a.end+1,5)); runs=defaultdict(list)
with open(a.csv,newline='',encoding='utf-8-sig') as f:
 for r in csv.DictReader(f):
  if r['trial_id'].strip(): runs[r['trial_id']].append(r)
summary=defaultdict(list);result=[];blocks=defaultdict(list)
for trial,rows in sorted(runs.items()):
 r=rows[0]; b=r['block']; cond=r['condition']; reason=[]; pts={}
 if cond not in ['B','L','M','H','T','N']:reason.append('invalid condition')
 if any(x['block']!=b or x['condition']!=cond for x in rows):reason.append('inconsistent metadata')
 if any(x['exclude_reason'].strip() for x in rows):reason.append('; '.join(sorted(set(x['exclude_reason'].strip() for x in rows if x['exclude_reason'].strip()))))
 try:
  delays=[float(x['connection_delay_s']) for x in rows if x['connection_delay_s'].strip()]
  if not delays or any(not math.isfinite(d) or d<0 or d>5 for d in delays):reason.append('missing or invalid connection delay, or delay >5 s')
  for x in rows:
   t=int(x['time_s']);v=x['volume_mL'].strip()
   if t in expected and v:
    if t in pts:reason.append('duplicate time')
    pts[t]=float(v)
    if not math.isfinite(pts[t]) or pts[t]<0 or pts[t]>=75:reason.append('invalid or stop-limit volume')
 except ValueError:reason.append('nonnumeric data')
 if set(pts)!=expected:reason.append('missing readings in fixed window')
 out={'trial_id':trial,'block':b,'condition':cond,'valid':not reason,'reason':'; '.join(reason)}
 if not reason:
  ts=sorted(pts);vs=[pts[t] for t in ts];mx=st.mean(ts);my=st.mean(vs);slope=sum((t-mx)*(v-my) for t,v in zip(ts,vs))/sum((t-mx)**2 for t in ts);intercept=my-slope*mx
  out.update(slope_mL_s=slope,intercept_mL=intercept,residuals_mL=[v-intercept-slope*t for t,v in zip(ts,vs)],warnings=['inspect curvature, control signal and depletion; no automatic exclusion'])
  summary[cond].append(slope);blocks[b,cond].append(slope)
 result.append(out)
stats={c:{'n':len(v),'mean_mL_s':st.mean(v),'sample_sd_mL_s':st.stdev(v) if len(v)>1 else None} for c,v in sorted(summary.items())}
contrasts={}
for b in sorted({x[0] for x in blocks}):
 contrasts[b]={f'{c}-{d}':st.mean(blocks[b,c])-st.mean(blocks[b,d]) for c,d in [('H','T'),('H','B'),('H','L')] if blocks.get((b,c)) and blocks.get((b,d))}
print(json.dumps({'window_s':[a.start,a.end],'trials':result,'condition_summary':stats,'within_block_contrasts_mL_s':contrasts,'note':'Descriptive only. Check traces and pilot validity; no equivalence or purified enzyme claim.'},indent=2,allow_nan=False))
