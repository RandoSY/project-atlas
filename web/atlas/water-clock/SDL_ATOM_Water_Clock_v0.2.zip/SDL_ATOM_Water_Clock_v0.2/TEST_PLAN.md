# Bench acceptance plan — SDL ATOM Water Clock v0.2

Use a trusted LAN and **real** M5Stack I²C weight module. Record PASS/FAIL and retain USB serial output.

1. [ ] Prior known-good ATOM Matrix 1.0 diagnostic still functions (baseline already reported successful).
2. [ ] Build with `pio run` from `PlatformIO/`; record firmware size and any warnings.
3. [ ] Set `upload_speed = 460800` and flash COM port; boot messages print at 115200 baud.
4. [ ] Boot LEDs sweep red/green/blue, then show meaningful status.
5. [ ] Serial identifies weight module at I²C `0x26`; no module results in a red error indication, without crash.
6. [ ] Connect only via USB for power (no second supply to ATOM); verify Grove module powered correctly and electrically compatible.
7. [ ] Connected STA gets ordinary router DHCP IP; device never broadcasts its own access point.
8. [ ] Firefox loads all **five** tabs from the ATOM IP with LAN connection.
9. [ ] Empty dry cup: tare yields 0 g; removing/restoring cup produces a detectable mass change.
10. [ ] Known calibration mass updates raw ADC; calibration yields expected mass; a *second* known mass agrees within measured uncertainty.
11. [ ] Start trial; samples advance at ≈2 Hz and chart updates ≈1 Hz.
12. [ ] A slow water drip increases mass; slope q is in g/s; flow graph is approximately constant for steady-head supply.
13. [ ] Mark event (browser and front button) and verify marker in exported data.
14. [ ] Long button press (>1.3 s) stops trial; short press starts the next if ready.
15. [ ] Disconnect browser for at least 30 seconds **while recording**, reconnect; no missing sample sequence numbers in recovered data.
16. [ ] Disrupt Wi-Fi router while recording, restore STA; acquisition continues and backlog is recovered.
17. [ ] Run three sequential trials, export CSV files, verify headers, row count, monotonic time and sequence IDs.
18. [ ] Fourth trial is explicitly refused; clear stored runs only after export; then a new trial is allowed.
19. [ ] Restart the ATOM: calibration factor persists, but the user must tare the cup again; prior trial data is gone as documented.
20. [ ] Confirm no AP-mode calls or WebSocket servers in source; inspect for blocking errors or resets during a 7-minute run.

**Known limitations:** A single standard Wi-Fi WebServer can briefly delay the acquisition loop on a slow or unstable client; export is therefore blocked while recording. For hard real-time guarantees in later releases, use a dedicated sampling task or loop-level scheduler with quantitative jitter logging. The current 2 Hz, nonblocking-loop design is intended for slow-scale classroom experiments.
