// SDL ATOM Matrix Galileo Water Clock v0.2.0 - original ESP32 ATOM Matrix 1.0
// Arduino ESP32 2.0.x; PlatformIO espressif32 6.7.0; M5Stack Atom board.
// 2 Hz sensor acquisition independent from HTTP. No AP mode. No cloud. No WebSockets.
// I2C Weight / Mini Scales: 0x26, RAW_ADC register 0x00; custom calibration in Preferences.
#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <Adafruit_NeoPixel.h>
#include <math.h>
#include "config.h"
#include "dashboard_html.h"

static constexpr uint8_t LED_COUNT=25;
static constexpr uint8_t WEIGHT_RAW_REG=0x00;
static constexpr uint16_t MAX_TRIAL_SAMPLES=900;  // 7.5 min @ 2 Hz
static constexpr uint8_t MAX_TRIALS=3;
static constexpr uint16_t MAX_PAGE_SAMPLES=180;
static constexpr uint32_t BUTTON_LONG_MS=1300;
static constexpr uint32_t WIFI_RETRY_MS=12000;

Adafruit_NeoPixel leds(LED_COUNT,PIN_MATRIX_LED,NEO_GRB+NEO_KHZ800);
WebServer server(WEB_PORT);
Preferences prefs;

struct Sample { uint32_t t_ms; float g; int32_t raw; uint16_t seq; uint8_t event; uint8_t reserved; };
struct Trial { uint32_t started;uint32_t ended;uint16_t count;uint8_t recording;uint8_t reserved;Sample samples[MAX_TRIAL_SAMPLES]; };
static Trial trials[MAX_TRIALS];
static uint8_t trialCount=0;
static int8_t activeTrial=-1;
static bool markPending=false;
static unsigned long lastSampleMs=0,lastLedMs=0,lastWiFiTry=0,lastSerialMs=0;
static bool scaleSeen=false,rawValid=false,tareReady=false,calFactorValid=false;
static int32_t latestRaw=0,tareRaw=0;
static float latestMass=0.0f,rawPerGram=0.0f;
static uint32_t failures=0,measurements=0,buttonPresses=0,lateSamples=0;
static bool webStarted=false;
static bool lastRawButton=false,stableButton=false;
static unsigned long buttonChanged=0,buttonDownMs=0;

static String ipText() {return WiFi.status()==WL_CONNECTED ? WiFi.localIP().toString() : String("offline");}
static bool recording() {return activeTrial>=0 && trials[activeTrial].recording;}
static float massFromRaw(int32_t raw) {return calFactorValid&&tareReady ? ((float)raw-(float)tareRaw)/rawPerGram : 0.0f;}
static bool beginScale() {
  Wire.begin(PIN_GROVE_SDA,PIN_GROVE_SCL);
  Wire.setClock(100000);
  Wire.setTimeOut(35);
  Wire.beginTransmission(WEIGHT_ADDR);
  return Wire.endTransmission()==0;
}
static bool readRawADC(int32_t &raw) {
  Wire.beginTransmission(WEIGHT_ADDR);
  Wire.write(WEIGHT_RAW_REG);
  if(Wire.endTransmission(false)!=0)return false;
  if(Wire.requestFrom((uint8_t)WEIGHT_ADDR,(uint8_t)4)!=(uint8_t)4)return false;
  uint32_t n=0;
  for(unsigned i=0;i<4;i++)n|=((uint32_t)Wire.read())<<(8*i);
  raw=(int32_t)n;
  return true;
}
static void stopTrial() {
  if(!recording())return;
  Trial &tr=trials[activeTrial];tr.recording=0;tr.ended=millis();
  Serial.printf("[TRIAL] stop #%d: %u samples, %lu ms elapsed\n",activeTrial+1,tr.count,(unsigned long)(tr.ended-tr.started));
  activeTrial=-1;
}
static bool startTrial() {
  if(recording()||!rawValid||!scaleSeen||!tareReady||!calFactorValid||trialCount>=MAX_TRIALS)return false;
  Trial &tr=trials[trialCount];tr.count=0;tr.started=millis();tr.ended=tr.started;tr.recording=1;
  activeTrial=trialCount++;markPending=false;
  Serial.printf("[TRIAL] start #%d\n",activeTrial+1);return true;
}
static void sampleScale(unsigned long now) {
  int32_t val=0;
  const bool ok=readRawADC(val);
  if(!ok){rawValid=false;failures++;scaleSeen=false;if(recording()){stopTrial();Serial.println("[ERROR] Sensor loss stopped trial");}return;}
  scaleSeen=true;rawValid=true;latestRaw=val;measurements++;
  if(calFactorValid&&tareReady) latestMass=massFromRaw(latestRaw);
  if(!recording())return;
  Trial &tr=trials[activeTrial];
  if(tr.count>=MAX_TRIAL_SAMPLES){stopTrial();return;}
  Sample &s=tr.samples[tr.count];
  s.t_ms=now-tr.started;s.g=latestMass;s.raw=val;s.seq=tr.count+1;s.event=markPending?1:0;s.reserved=0;
  tr.count++;markPending=false;
  if(tr.count>=MAX_TRIAL_SAMPLES){Serial.println("[TRIAL] buffer full, auto-stop");stopTrial();}
}
static void handleButton(unsigned long now) {
  bool raw=(digitalRead(PIN_FRONT_BUTTON)==LOW);
  if(raw!=lastRawButton){lastRawButton=raw;buttonChanged=now;}
  if((uint32_t)(now-buttonChanged)<35 || raw==stableButton)return;
  stableButton=raw;
  if(raw){buttonDownMs=now;return;}
  buttonPresses++;
  uint32_t held=now-buttonDownMs;
  if(held>=BUTTON_LONG_MS){if(recording())stopTrial();else Serial.println("[BUTTON] long press: no trial running");}
  else if(recording()){markPending=true;Serial.println("[BUTTON] event marked");}
  else if(!startTrial())Serial.println("[BUTTON] start rejected: tare/calibrate/connect first, or archive full");
}
static uint32_t rgb(uint8_t r,uint8_t g,uint8_t b){return leds.Color(r,g,b);}
static void ledStatus(unsigned long now){
  if((uint32_t)(now-lastLedMs)<160)return;
  lastLedMs=now;leds.clear();
  if(!scaleSeen || !rawValid){ { const uint8_t redPositions[5]={0,4,12,20,24};for(uint8_t i=0;i<5;i++)leds.setPixelColor(redPositions[i],rgb(105,0,0)); } }
  else if(recording()){
    for(uint8_t i=0;i<25;i++) if(i==0||i==4||i==20||i==24||i==12)leds.setPixelColor(i,rgb(0,90,28));
    if((now/500)%2==0)leds.setPixelColor(12,rgb(0,180,65));
  }else if(!tareReady||!calFactorValid){leds.setPixelColor(12,rgb(140,85,0));}
  else if(WiFi.status()==WL_CONNECTED){leds.setPixelColor(12,rgb(0,48,145));}
  else {leds.setPixelColor(12,(now/750)%2?rgb(125,50,0):rgb(0,0,0));}
  if(stableButton)leds.setPixelColor(24,rgb(70,70,0));
  leds.show();
}
static void jsonError(const char* message,int status=409){
  String v=String("{\"ok\":false,\"error\":\"")+message+"\"}";
  server.send(status,"application/json",v);
}
static void jsonOK(const String &s="{\"ok\":true}"){server.send(200,"application/json",s);}
static void statusAPI(){
  uint16_t n=0,ev=0;uint32_t elapsed=0;
  if(recording()){
    Trial &t=trials[activeTrial];n=t.count;elapsed=millis()-t.started;
    for(int i=0;i<t.count;i++)if(t.samples[i].event)ev++;
  }else if(trialCount){for(int i=0;i<trials[trialCount-1].count;i++)if(trials[trialCount-1].samples[i].event)ev++;}
  String s;s.reserve(480);
  s+="{\"ok\":true,\"firmware\":\"0.2.0\",\"board\":\"ATOM Matrix 1.0\"";
  s+=",\"ip\":\""+ipText()+"\",\"sta\":";s+=(WiFi.status()==WL_CONNECTED?"true":"false");
  s+=",\"ssid_configured\":";s+=(strlen(WIFI_SSID)?"true":"false");
  s+=",\"sensor_ok\":";s+=(scaleSeen&&rawValid?"true":"false");
  s+=",\"calibrated\":";s+=(calFactorValid&&tareReady?"true":"false");
  s+=",\"tare_ready\":";s+=(tareReady?"true":"false");
  s+=",\"factor_valid\":";s+=(calFactorValid?"true":"false");
  s+=",\"recording\":";s+=(recording()?"true":"false");
  s+=",\"grams\":"+String(latestMass,3);
  s+=",\"raw_valid\":";s+=(rawValid?"true":"false");
  s+=",\"raw\":"+String(latestRaw);
  s+=",\"elapsed_ms\":"+String(elapsed);
  s+=",\"event_count\":"+String(ev);
  s+=",\"sample_count\":"+String(n);
  s+=",\"trial_count\":"+String(trialCount);
  s+=",\"sample_rate_hz\":2,\"max_samples_per_trial\":"+String(MAX_TRIAL_SAMPLES);
  s+=",\"i2c_address\":\"0x26\",\"i2c_sda\":26,\"i2c_scl\":32";
  s+=",\"button_presses\":"+String(buttonPresses);
  s+=",\"measurement_count\":"+String(measurements);
  s+=",\"read_failures\":"+String(failures);
  s+=",\"late_samples\":"+String(lateSamples);
  s+=",\"free_heap\":"+String(ESP.getFreeHeap());
  s+="}";jsonOK(s);
}
static void trialsAPI(){
  String s="{\"ok\":true,\"trials\":[";
  for(uint8_t i=0;i<trialCount;i++){
    Trial &t=trials[i];
    if(i)s+=',';
    s+="{\"id\":"+String(i)+",\"count\":"+String(t.count);
    s+=",\"recording\":";s+=(t.recording?"true":"false");
    s+=",\"duration_ms\":"+String((t.recording?millis():t.ended)-t.started);
    s+=",\"last_g\":"+String(t.count?t.samples[t.count-1].g:0.0f,3)+"}";
  }
  s+="]}";jsonOK(s);
}
static void samplesAPI(){
  int id=server.arg("trial").toInt();
  if(id<0||id>=trialCount){jsonError("Invalid trial",404);return;}
  int after=max(0,server.arg("after").toInt());
  int limit=constrain(server.arg("limit").toInt(),1,(int)MAX_PAGE_SAMPLES);
  Trial &t=trials[id];
  String s;s.reserve(12000);s="{\"ok\":true,\"trial\":"+String(id)+",\"samples\":[";
  bool comma=false;int sent=0;int last=after;
  for(int i=0;i<t.count&&sent<limit;i++){
    const Sample &p=t.samples[i];if(p.seq<=after)continue;
    if(comma)s+=',';
    comma=true;
    s+="{\"seq\":"+String(p.seq)+",\"t_ms\":"+String(p.t_ms);
    s+=",\"g\":"+String(p.g,3)+",\"raw\":"+String(p.raw);
    s+=",\"event\":";s+=(p.event?"true":"false");s+='}';
    last=p.seq;sent++;
  }
  s+= "],\"more\":";s+=(last<t.count?"true":"false");s+="}";
  jsonOK(s);
}
static void csvAPI(){
  int id=server.arg("trial").toInt();
  if(id<0||id>=trialCount){jsonError("Invalid trial",404);return;}
  if(recording()){jsonError("Stop active trial before exporting CSV");return;}
  Trial &t=trials[id];
  server.sendHeader("Content-Disposition","attachment; filename=water_clock_trial_"+String(id+1)+".csv");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200,"text/csv","seq,t_ms,t_s,mass_g,raw_adc,event\r\n");
  String block;block.reserve(3072);
  for(int i=0;i<t.count;i++){
    const Sample &p=t.samples[i];
    block+=String(p.seq)+","+String(p.t_ms)+","+String(p.t_ms/1000.0f,3)+",";
    block+=String(p.g,3)+","+String(p.raw)+","+String((int)p.event)+"\r\n";
    if(block.length()>2048){server.sendContent(block);block="";}
  }
  if(block.length())server.sendContent(block);
  server.sendContent("");
}
static bool validScale(){return scaleSeen&&rawValid;}
static void commandAPI(const String &action){
  if(action=="start"){
    if(recording()) {jsonError("Already recording");return;}
    if(!calFactorValid){jsonError("Calibrate with known mass first");return;}
    if(!tareReady){jsonError("Tare empty vessel first");return;}
    if(!validScale()){jsonError("Scale not responding on I2C 0x26");return;}
    if(trialCount>=MAX_TRIALS){jsonError("Three trials stored; export and clear first");return;}
    if(!startTrial()){jsonError("Cannot start trial");return;}
    jsonOK("{\"ok\":true,\"trial\":"+String(activeTrial)+"}");return;
  }
  if(action=="stop"){
    if(!recording()){jsonError("No trial running");return;}stopTrial();jsonOK();return;
  }
  if(action=="mark"){
    if(!recording()){jsonError("Start a trial first");return;}markPending=true;jsonOK();return;
  }
  if(action=="tare"){
    if(recording()){jsonError("Stop trial before taring");return;}
    if(!validScale()){jsonError("Scale not responding on I2C 0x26");return;}
    tareRaw=latestRaw;tareReady=true;latestMass=0;
    Serial.printf("[SCALE] tare = %ld raw counts\n",(long)tareRaw);jsonOK();return;
  }
  if(action=="calibrate"){
    if(recording()){jsonError("Stop trial before calibrating");return;}
    if(!validScale()||!tareReady){jsonError("Connect scale and tare EMPTY vessel first");return;}
    float grams=server.arg("grams").toFloat();
    if(!isfinite(grams)||grams<1.0f||grams>100000.0f){jsonError("Enter known mass in grams (1–100000)");return;}
    int32_t change=latestRaw-tareRaw;
    if(labs((long)change)<100){jsonError("Calibration signal too small; put known mass on scale");return;}
    float factor=(float)change/grams;
    if(!isfinite(factor)||fabsf(factor)<0.001f){jsonError("Invalid calibration");return;}
    rawPerGram=factor;calFactorValid=true;
    prefs.putFloat("counts_g",rawPerGram);latestMass=massFromRaw(latestRaw);
    Serial.printf("[SCALE] calibrated %.3f raw counts/gram\n",rawPerGram);jsonOK();return;
  }
  if(action=="clear"){
    if(recording()){jsonError("Stop trial before clearing");return;}
    trialCount=0;activeTrial=-1;markPending=false;jsonOK();return;
  }
  if(action=="scan"){
    if(recording()){jsonError("Stop trial before scanning");return;}
    bool p=beginScale();scaleSeen=p;
    Serial.printf("[I2C] address 0x26 %s\n",p?"present":"missing");
    jsonOK(String("{\"ok\":true,\"found\":")+(p?"true":"false")+",\"address\":\"0x26\"}");return;
  }
  jsonError("Unknown command",404);
}
static void configureRoutes(){
  server.on("/",HTTP_GET,[]{server.send_P(200,"text/html; charset=utf-8",DASHBOARD_HTML);});
  server.on("/api/status",HTTP_GET,statusAPI);
  server.on("/api/trials",HTTP_GET,trialsAPI);
  server.on("/api/samples",HTTP_GET,samplesAPI);
  server.on("/api/trial.csv",HTTP_GET,csvAPI);
  const char* actions[]={"start","stop","mark","tare","calibrate","clear","scan"};
  for(const char* action:actions){const String cmd=String(action);server.on(String("/api/")+cmd,HTTP_POST,[cmd](){commandAPI(cmd);});}
  server.onNotFound([](){jsonError("Not found",404);});
}
static void maintainWiFi(unsigned long now){
  if(WIFI_SSID[0]=='\0')return;
  if(WiFi.status()==WL_CONNECTED){
    if(!webStarted){server.begin();webStarted=true;Serial.print("[WIFI] SDL dashboard http://");Serial.println(WiFi.localIP().toString());}
    return;
  }
  if(webStarted){Serial.println("[WIFI] link dropped; recordings continue");webStarted=false;}
  if((uint32_t)(now-lastWiFiTry)<WIFI_RETRY_MS)return;
  lastWiFiTry=now;
  Serial.println("[WIFI] STA reconnecting (no AP fallback)");
  WiFi.disconnect(false);WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
}
void setup(){
  Serial.begin(115200);delay(300);
  Serial.println("\n=== SDL Galileo Water Clock v0.2.0 | ATOM Matrix 1.0 ===");
  pinMode(PIN_FRONT_BUTTON,INPUT);
  leds.begin();leds.setBrightness(16);leds.clear();leds.show();
  for(int pass=0;pass<3;pass++){
    uint32_t c=pass==0?rgb(180,0,0):(pass==1?rgb(0,150,0):rgb(0,0,180));
    leds.fill(c);leds.show();delay(180);
  }
  prefs.begin("sdlscale",false);rawPerGram=prefs.getFloat("counts_g",0.0f);
  calFactorValid=isfinite(rawPerGram)&&fabsf(rawPerGram)>0.001f;
  tareReady=false; // Never reuse a vessel tare across reboot.
  scaleSeen=beginScale();Serial.printf("[I2C] scale address 0x26: %s\n",scaleSeen?"ACK":"missing");
  int32_t v=0;if(scaleSeen&&readRawADC(v)){latestRaw=v;rawValid=true;}
  Serial.printf("[CAL] saved scale factor: %s. Tare at startup!\n",calFactorValid?"yes":"no");
  configureRoutes();
  WiFi.persistent(false);WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(true);
  if(WIFI_SSID[0]){WiFi.begin(WIFI_SSID,WIFI_PASSWORD);lastWiFiTry=millis();Serial.print("[WIFI] joining STA network ");Serial.println(WIFI_SSID);}
  else Serial.println("[WIFI] no SSID in config.h. USB tests still work. NO ACCESS POINT.");
  lastSampleMs=millis();
  Serial.println("[BUTTON] short: start / mark; hold 1.3 s: stop");
}
void loop(){
  unsigned long now=millis();
  handleButton(now);
  if((uint32_t)(now-lastSampleMs)>=SCALE_INTERVAL_MS){
    if((uint32_t)(now-lastSampleMs)>SCALE_INTERVAL_MS+150)lateSamples++;
    lastSampleMs=now;  // No fake catch-up readings with nearly identical timestamps.
    sampleScale(now);
  }
  maintainWiFi(now);
  if(webStarted&&WiFi.status()==WL_CONNECTED)server.handleClient();
  ledStatus(now);
  if((uint32_t)(now-lastSerialMs)>=5000){
    lastSerialMs=now;
    Serial.printf("[SDL] %s mass=%.2fg raw=%ld calibrated=%d trial=%d samples=%u ip=%s free=%u\n",scaleSeen?"scale OK":"scale missing",latestMass,(long)latestRaw,(int)(tareReady&&calFactorValid),(int)activeTrial,(unsigned)(recording()?trials[activeTrial].count:0),ipText().c_str(),(unsigned)ESP.getFreeHeap());
  }
  delay(1);
}
