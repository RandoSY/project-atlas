#pragma once
// SDL ATOM Matrix 1.0 - Galileo Water Clock, experiment 03.
// Configure these only. Use your normal 2.4 GHz Wi-Fi LAN: STA mode; never an AP.
// Do NOT commit a file containing your private password to a public repository.
static const char* const WIFI_SSID     = "";    // <-- Enter your home Wi-Fi name
static const char* const WIFI_PASSWORD = "";    // <-- Enter your home Wi-Fi password

// Two readings each second. Scale and browser are deliberately low bandwidth.
static const unsigned SCALE_INTERVAL_MS = 500;
static const unsigned WEB_PORT = 80;
// Grove I2C signals for ORIGINAL Atom Matrix (ESP32-PICO-D4), not AtomS3R.
static const int PIN_GROVE_SDA = 26;
static const int PIN_GROVE_SCL = 32;
static const int PIN_MATRIX_LED = 27;
static const int PIN_FRONT_BUTTON = 39;
static const uint8_t WEIGHT_ADDR = 0x26;
