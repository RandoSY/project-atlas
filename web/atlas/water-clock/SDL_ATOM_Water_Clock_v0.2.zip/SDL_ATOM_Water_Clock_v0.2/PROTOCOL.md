# SDL Water Clock v0.2 — HTTP API

All routes are served by the ATOM's **STA** IP address; there is no AP and no WebSocket. Sensor sampling is independent from client connections.

### GET routes

- `/` — one-page five-tab HTML/JS dashboard.
- `/api/status` — `{ok,firmware,board,ip,sta,ssid_configured,sensor_ok,calibrated,tare_ready,factor_valid,recording,grams,raw_valid,raw,elapsed_ms,event_count,sample_count,trial_count,sample_rate_hz,max_samples_per_trial,i2c_address,i2c_sda,i2c_scl,button_presses,measurement_count,read_failures,late_samples,free_heap}`.
- `/api/trials` — `{ok,trials:[{id,count,recording,duration_ms,last_g}]}`. Trial IDs start at zero.
- `/api/samples?trial=N&after=SEQ&limit=180` — incremental readings: `{ok,trial,samples:[{seq,t_ms,g,raw,event}],more}`. Sequence numbers are **1-based per trial**. `after=0` fetches from the beginning. Call again if `more=true`.
- `/api/trial.csv?trial=N` — six-column CSV: `seq,t_ms,t_s,mass_g,raw_adc,event`. Only while *not recording*. Response has Content-Disposition attachment.

### POST commands

- `/api/scan` — checks `0x26`; returns `{ok,found,address}`.
- `/api/tare` — records current raw ADC as empty-vessel zero; forbidden during acquisition.
- `/api/calibrate?grams=100` — after taring and applying **known 100 g mass**, derive raw counts/gram; the factor persists via Preferences; forbidden during acquisition.
- `/api/start` — starts the next available trial; returns `{ok,trial}`; requires connected scale + tare + valid calibration.
- `/api/mark` — adds a marker to the next sample of an active trial.
- `/api/stop` — ends current trial.
- `/api/clear` — clears stored trials **only when not recording**. Irreversible.

All commands that fail return an `ok:false` JSON object and a non-2xx status. This LAN-only server intentionally omits authentication; keep it on a trusted network.

### Sample record

```
{"seq":42,"t_ms":21000,"g":19.835,"raw":1876543,"event":false}
```

This is **illustrative protocol data**, not a device reading.

### Future compatibility

The web UI speaks the instrument protocol, not board-specific API calls. An Atom-Matrix v1.1 or AtomS3R port should preserve these route shapes and change hardware/pin definitions only as needed. This version is intended for original Matrix 1.0; newer hardware has not been tested.
