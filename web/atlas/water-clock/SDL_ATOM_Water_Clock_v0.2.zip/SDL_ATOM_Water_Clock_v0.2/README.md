# SDL ATOM Matrix 1.0 — Galileo's Water Clock

**Version:** 0.2.0 — bench-test candidate | **Controller:** original M5Stack ATOM Matrix 1.0, ESP32-PICO-D4 | **Sensor:** M5Stack Weight-I²C Unit or Mini Scales Unit at `0x26`

> This is an independently built, runnable firmware **candidate**, not yet validated on your scale. You confirmed the earlier ATOM checkout sketch operates on your hardware; that does not automatically validate this new sensor acquisition. Test on real equipment and share your logs.

For the scope distinction between this first release and eventual Vernier-class features, see **`FEATURE_SCOPE.md`**. The immediate goal is a stable single-sensor water-clock laboratory, not a general-purpose analysis suite.

## The idea

*How do we measure how long a ball takes to roll down a ramp when we don't have a precise clock?*

Galileo described allowing water to flow while the ball traveled, collecting the water, and weighing it. For steady flow, the greater the collected mass, the longer the elapsed time. This experiment uses a modern load cell to inspect the **clock itself**, and then asks students to connect calibrated water mass to a falling or rolling object's motion. The history is narrated in the browser dashboard's Galileo sidebar.

The central question is not whether the graph looks good, but whether a calibration **predicts the durations of new trials** and whether residuals reveal a changing rate of flow.

## Hardware and electrical precautions

- USB-C data/power cable to ATOM Matrix 1.0 (USB supplies the controller's power).
- M5Stack **Weight I²C Unit** with connected compatible load cell **or** M5Stack **Mini Scales Unit**. Their common weight registers use the **I²C address `0x26`**.
- Grove 4-pin cable connected to the ATOM external port. **For original ATOM Matrix:** ESP32 GPIO26 = SDA, GPIO32 = SCL. The software sets up 100 kHz I²C.
- External **Grove port supplies 5 V**. Check your module's I²C signal-level tolerance, connectors and pull-ups; ESP32 GPIO is not 5 V tolerant. Do not use a bare 5 V-only I²C board without level shifting.
- Collection cup, stable platform, plastic tubing, water reservoir and catch basin. Keep the USB controller and all exposed electronics **away from water**. The tubing must not touch, support or pull the cup; otherwise the scale measures tubing forces.
- No Hub, relay, SD card, internet service or second microcontroller is required for the initial single-sensor trial.

## Recommended build — PlatformIO on Windows

Extract the ZIP and open PowerShell:

```powershell
cd .\SDL_ATOM_Water_Clock_v0.2\PlatformIO
notepad .\include\config.h
```

Set the two strings (edit only your local copy):

```cpp
static const char* const WIFI_SSID     = "YOUR_2_4GHz_SSID";
static const char* const WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
```

**Never send your Wi-Fi password in chat or push it to a public GitHub repository.** The board joins your existing home network. It uses `WiFi.mode(WIFI_STA)` and **never** creates an access point.

Then build and upload on the **actual COM port** shown in Device Manager:

```powershell
pio run
pio run -t upload --upload-port COM30
pio device monitor --port COM30 --baud 115200
```

Upload speed is set to **460800** in `platformio.ini`, as chosen after your earlier high-speed upload failure. If flashing fails, change `upload_speed = 230400` or `115200` in `platformio.ini` and retry.

After boot, the USB console prints the dashboard URL:

```text
[WIFI] SDL dashboard http://192.168.0.xxx
```

Open the URL in **Firefox** on a computer on the same LAN. The instrument itself serves the complete HTML/JS dashboard over port 80; the browser does not need to open a file or use an app. With blank/incorrect Wi-Fi credentials the USB/Sensor/LED functions continue, but there is **no AP fallback**.

For Arduino IDE, an equivalent source is in `Arduino/SDL_ATOM_Water_Clock/`. Change its local `config.h`; select `M5Atom` in ESP32 board package; install `Adafruit NeoPixel` library. The PlatformIO project is the recommended primary reference.

## First live experiment (about 4 minutes)

1. Connect the I²C weight module and a **dry, empty** cup on the scale; boot the ATOM. On the Setup tab, click **Check I²C**; it must report address `0x26`.
2. Click **Tare empty vessel**. This defines the zero mass for this session.
3. Add a **known calibration mass** (for example, a measured 100 g reference mass), enter its value in Setup and click **Calibrate**. Remove the mass. The scale's raw ADC-to-grams factor is saved in ESP32 preferences; tare again after a reboot or when changing containers.
4. Verify approximately zero grams when the reference mass has been removed; check a second known mass if possible.
5. Click **Start trial**. Begin dripping water into the vessel, without the tubing mechanically contacting the vessel or its platform. The graph should rise as water accumulates.
6. Use **Mark event** or a short button press to mark a change in drip rate. Stop via the browser or long-press (>1.3 s) the ATOM button.
7. Open **Analysis**: graph mass vs time, derived flow rate, least-squares straight-line model, and residuals. Open **Archive** and export the trial CSV.
8. Repeat twice for comparison. **Three** trials can coexist in RAM. Export them before power-off; clearing or losing power deletes the trial samples.

### ATOM LED/button controls

| LED pattern | Meaning |
|---|---|
| Brief red, green, blue on boot | Original LED checkout |
| Red X pattern | Weight module not responding; I²C issue |
| Amber center | Scale needs a tare or known-mass calibration |
| Blue center | Ready / STA connected |
| Blinking amber center | Ready but no Wi-Fi link |
| Green pattern | Recording; activity pulse |

**Short button press:** if ready, start a trial; if recording, mark an event. **Hold for 1.3 seconds:** stop the current trial. This changes the diagnostic sketch's button functions deliberately for the water-clock experiment.

## Measurement and calculation

- **Acquisition:** 2 samples/s (500 ms between scale reads); dashboard polls approximately once/s with ordinary HTTP.
- **Firmware samples:** raw ADC count, locally calibrated mass in grams, elapsed milliseconds, event flag, sequential sample ID.
- **Calibration:** raw signed ADC at register `0x00`; zero/tare raw offset; conversion factor derived from one known test mass. This *does not overwrite the scale module's factory registers*.
- **Flow:** estimate `Δm / Δt` over an approximately 5 s sliding window (g/s), displayed in Analysis.
- **Linear model:** `m(t) = a + qt`; the slope `q` estimates mean mass flow, and residuals show how the measured water clock departs from an ideal constant-flow model.
- **At ~room temperature:** 1 g of water is approximately 1 mL, but volume/density are optional extensions; the experiment directly measures **mass**.
- The water-clock experiment measures *water collected over elapsed time*. It does not directly measure ball acceleration. The Galileo ramp is a **separate transfer investigation**, where the clock's calibration estimates rolling intervals; a model from rest predicts `distance ∝ time²`.

## Storage and capacity

- **900 samples per trial** = 7.5 minutes at 2 Hz; **3 sequential trials** in RAM.
- Capacity limit stops collection rather than silently overwriting old data.
- Acquisition is independent of dashboard connection. The browser catches up using `GET /api/samples?trial=N&after=sequence`.
- CSV export is only permitted when no trial is actively recording, to prevent HTTP streaming from interrupting a measurement.
- The calibration factor persists in ESP32 Preferences (NVS); **data samples do not** persist through power loss/reset.
- HTTP is **unencrypted and unauthenticated** and intended only for a trusted local LAN. Do not port-forward it or expose it publicly.

## Source layout

```text
PlatformIO/
  platformio.ini                 stable ESP32-PICO-D4 target, baud 460800
  include/config.h              EDIT Wi-Fi credentials here (STA only)
  include/dashboard_html.h      generated embedded five-tab dashboard
  src/main.cpp                  controller firmware + scale + HTTP API
Arduino/SDL_ATOM_Water_Clock/
  SDL_ATOM_Water_Clock.ino      same firmware, Arduino IDE-compatible
  config.h / dashboard_html.h   matching headers

docs/dashboard.html             dashboard source of truth, editable
README.md                       this guide
PROTOCOL.md                     HTTP protocol
TEST_PLAN.md                    commissioning and acceptance checks
tools/smoke_check.py            read-only live-device checks
```

## Firmware status and source references

- Official M5Stack `M5Unit-WeightI2C` library: https://github.com/m5stack/M5Unit-WeightI2C (`RAW_ADC_REG = 0x00`, `DEVICE_DEFAULT_ADDR = 0x26`).
- Official `M5Unit-Miniscale` library: https://github.com/m5stack/M5Unit-Miniscale (same `0x00`/`0x26` core registers).
- ATOM original pins derived from M5Stack Atom docs and previously working diagnostic. New unit tests rely on real scale hardware.
- See `VALIDATION.txt` for test limitations. Do **not** call this release hardware-verified until a real bench test passes.
