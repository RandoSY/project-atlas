#!/usr/bin/env python3
"""Read-only live ATOM Water Clock checks. Usage: py -3 tools/smoke_check.py 192.168.0.125"""
from urllib.request import urlopen
import argparse, json, sys, time

def get(base, route):
    with urlopen(base + route, timeout=5) as r:
        return json.load(r)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('ip', help='ATOM DHCP IPv4 or http://address')
    x=p.parse_args().ip.strip().rstrip('/')
    base=x if x.startswith('http://') else 'http://'+x
    try:
        a=get(base,'/api/status')
        assert a.get('firmware')=='0.2.0', 'Wrong firmware'
        assert a['sta'] and a['ip']!='offline', 'STA disconnected'
        assert a.get('sample_rate_hz')==2, 'Wrong sample rate'
        print('PASS: firmware v0.2.0, STA:',a['ip'])
        if not a['sensor_ok']:
            print('FAIL: I2C weight module missing or not reading');return 1
        print('PASS: I2C scale 0x26; latest raw:',a['raw'])
        c=a['measurement_count']; time.sleep(2)
        b=get(base,'/api/status')
        assert b['measurement_count'] >= c+3, 'Sensor sample counter not advancing ~2 Hz'
        print('PASS: samples advanced:',c,'→',b['measurement_count'])
        t=get(base,'/api/trials')
        assert isinstance(t['trials'],list), 'Invalid trial archive'
        print('PASS: trial index readable:',len(t['trials']),'trials')
        print('PENDING: visual LED/button checks, tare/calibration, water-run, CSV and disconnect tests')
        return 0
    except Exception as e:
        print('FAIL:',str(e),file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
