# SDL Graphical Analysis — Water Clock Release Scope

## Scope decision (CORE10 Water Clock v0.2)

The **long-term** ambition is feature equivalence with the scientific functions of Vernier Graphical Analysis where useful, **not** copying its appearance or proprietary ecosystem. For this first physical experiment, implement only tools that support scientific inquiry with a 2 Hz I²C scale. Preserve the compact SQM+-inspired five-tab interface.

### Included in v0.2

- **Live**: mass (g), elapsed time (s), rolling flow (g/s), mass-versus-time graph, start/stop, tare, event marks.
- **Experiments**: Galileo's water-clock introduction, inclined-plane connection, student investigation prompts and sidebar.
- **Analysis**: flow versus time, ordinary least-squares line, mean mass-flow slope, RMSE, residual plot.
- **Archive**: up to three sequential RAM-resident trials, CSV downloads, incremental sample retrieval after browser or Wi-Fi interruption.
- **Setup**: scale detection at I²C address 0x26, known-mass calibration, raw ADC and diagnostic readout.
- **Transport and hardware**: original ATOM Matrix 1.0 ESP32-PICO-D4, I²C scale on GPIO26/32, USB power, Wi-Fi STA only, built-in HTTP server, no AP fallback or WebSockets. 2 Hz sampling and ~1 Hz display refresh.

### Deliberately deferred

- FFTs, histograms, categorical/bar plots, log axes, dual Y axes, advanced/hand-fit regressions and user-defined formulas.
- General multi-sensor support, synchronization with video, device-to-device sharing, investigation library, classroom management.
- Generic Bluetooth or USB browser connections, PWA/offline-install features, advanced user-defined calculated columns.
- Formal WCAG 2.2 AA compliance certification (accessibility will be improved iteratively).

### Architecture obligations for the future

- Keep acquisition independent of the browser; no missing readings after transient Wi-Fi failure within the ring/buffer limit.
- Every sample has time, sequence, value, units, calibration and trial identity (currently units/calibration are per device; schema may later evolve).
- Do not weld scientific models or lesson text to one physical board. Hardware adapters can later target ATOM Matrix 1.1, AtomS3R, UNO Q, Pico/MSP430.
- Maintain an explicit versioned wire protocol; test backwards compatibility before changing route shapes.
- Do not claim advanced scientific capabilities or real-hardware validation before those have been implemented and tested.
